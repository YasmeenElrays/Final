package Pages;

import DriverBase.Base;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;


public class DiscussionRoom extends PageBase{

    public DiscussionRoom(WebDriver driver) {
        super(driver);
        scroll = (JavascriptExecutor)driver;
    }
    UserLogin LoginTest=new UserLogin(driver);

    @FindBy(xpath = "//*[@id=\"teacherCoursesTitle\"]/li[1]/a")
    WebElement ClickOnCourse;
    @FindBy(xpath = "//*[@id=\"browseContent\"]/div/div/div[2]/div/section[3]/h2/div/div/a")
    WebElement AddButton;
    @FindBy(xpath = "/html/body/div[6]/div/div[3]/div[5]/div[2]/div[4]/section/section/div/div/div[2]/div/section[3]/h2/div/div/a\n")
    WebElement Add2;
    @FindBy(id = "PostTitle")
    WebElement Title;
    @FindBy(id = "submit_button")
    WebElement Next;
    @FindBy(id = "UserCheckbox78785")
    WebElement ChooseStudent;
    @FindBy(id = "back_button")
    WebElement Previous;
    @FindBy(xpath = "//*[@id=\"browseContent\"]/div/div/div[2]/div/div[1]/input")
    WebElement SearchField;
    @FindBy(xpath = "/html/body/div[6]/div/div[3]/div[5]/div/div[2]/section/section/div/div/div[2]/div/div[1]/input")
    WebElement SearchFieldManager;
    @FindBy(xpath = "//*[@id=\"browseContent\"]/div/div/div[2]/div/section[3]/h2")
    WebElement ArrowDown;
    //@FindBy(xpath = "//a[@href='/teacher/posts/view']")
    @FindBy(xpath = "//*[@id=\"sidebar\"]/ul[1]/li[9]/a")
    WebElement DiscussionSideMenu;
    @FindBy(id="discussion_autosearch")
    WebElement SearchField2;
    @FindBy(xpath ="//a[@href='/teacher']")
    WebElement Home;
    @FindBy(linkText = "AutomationDissroom")
    WebElement DisTitle;
    @FindBy(xpath = "//*[@id=\"content_wrapper\"]/div[3]/div[5]/ul/li[1]/a")
    WebElement ShowAllButton;
    @FindBy(xpath = "//*[@id=\"browseContent\"]/div/div/div[2]/div/section[3]/div/div/div[1]/div/div[1]/a")
    WebElement MoreActions;
    @FindBy( xpath = "//*[@id=\"browseContent\"]/div/div/div[2]/div/section[3]/div/div/div[1]/div/div[1]/ul/li[2]/a")
    WebElement Preview;
    @FindBy(xpath = "//*[@id=\"browseContent\"]/div/div/div[2]/div/section[3]/div/div/div[1]/div/div[1]/ul/li[1]/a")
    WebElement Edit;
    @FindBy(xpath = "//a[@href='/teacher/posts/view']")
    WebElement AllDiscussion;
    @FindBy(xpath ="//body/div[6]/div[1]/div[3]/div[5]/div[1]/div[1]/form[1]/a[1]")
    WebElement CreatePost;
    @FindBy(xpath = "/html[1]/body[1]/div[6]/div[1]/div[3]/div[5]/div[2]/div[1]/form[1]/a[1]")
    WebElement CreateRoom2;
    @FindBy(linkText = "Posts List")
    WebElement PostsList;
    @FindBy(id="flashMessage")
    WebElement FlashMsg;
    @FindBy(xpath = "//*[@id=\"browseContent\"]/div/div/div[2]/div/div[1]/input")
    WebElement SearchField3;
    @FindBy(linkText = "Delete")
    WebElement Delete;
    @FindBy(xpath = "//*[@id=\"content_wrapper\"]/div[1]/div/h3")
    WebElement ExpectedMsg;
    @FindBy(xpath = "/html/body/div[6]/div/div[3]/div[5]/div[1]/div[1]/div/div/div/a/h3\n")
    WebElement SearchResults;
    @FindBy(xpath = "//i[contains(text(),'1')]")
    WebElement ClickOnDiscussionRooms;
    @FindBy(id = "PostHideComments")
    WebElement HideAllNewTopics;
    @FindBy(xpath = "//i[contains(text(),'0')]")
    WebElement ClickOnDiscussionRoomDeleteResults;
    @FindBy(xpath = "//*[@id=\"content_wrapper\"]/div[3]/div[3]/label")
    WebElement AddPost;
    @FindBy(xpath = "/html/body")
    WebElement InsideFrame;
    @FindBy(xpath = "//*[@id=\"PostReplyForm\"]/button")
    WebElement AddPostButton;
    @FindBy(xpath = "//*[@id=\"finishExamPopUp\"]/div/div/div[1]/button")
    WebElement CloseCongratulationFrame;
    @FindBy(xpath = "//h3[contains(text(),'CreateFromModule')]")
    WebElement SearchInModulePage;


    public void Course(){
        ClickOnCourse.click();
    }
    public void CreateDiscussionRoom(){
        ScrollDown();
        AddButton.click();
        Title.sendKeys("AutomationDissroom");
        Next.click();
        ChooseStudent.click();
        Previous.click();
        Next.click();
        Next.click();
    }
    public void CreateDisRoomWithHideAllTopics(){
        Home.click();
        ClickOnCourse.click();
        ScrollDown();
        AddButton.click();
        Title.sendKeys("AutomationDisroomWithHideAllOption");
        HideAllNewTopics.click();
        Next.click();
        ChooseStudent.click();
        Next.click();
        ScrollDown();
        ScrollDown();
        ArrowDown.click();
        MoreActions.click();
        Preview.click();
        AddPost.click();
        driver.switchTo().frame(0);
        InsideFrame.sendKeys("Post hide test");
        driver.switchTo().defaultContent();
        AddPostButton.click();
        CloseCongratulationFrame.click();
        driver.navigate().back();
        ScrollUp();

    }
    public void SearchWithName(){
        SearchField.sendKeys("AutomationDissroom");
        Assert.assertTrue(ClickOnDiscussionRooms.isDisplayed());
    }
    public void SearchInDiscussionRoomModule(){
        ScrollDown();
        DiscussionSideMenu.click();
        SearchField2.sendKeys("AutomationDissroom");
        Assert.assertTrue(SearchResults.isDisplayed());
        System.out.println(SearchResults.getText());
    }
    public void ViewDiscussionRooms(){
        Home.click();
        ClickOnCourse.click();
        ScrollDown();
        ArrowDown.click();
        DisTitle.click();
        waitForElement(ShowAllButton,30);
        Boolean Display = ShowAllButton.isDisplayed();
        System.out.println("Element displayed is :"+ Display);
        driver.navigate().back();
        ArrowDown.click();
        MoreActions.click();
        Preview.click();
    }
    public void EditDiscussionRoom(){
        driver.navigate().back();
        ArrowDown.click();
        MoreActions.click();
        Edit.click();
        Title.sendKeys("Edit");
        ScrollDown();
        Next.click();
        driver.navigate().back();
        ScrollUp();
        AllDiscussion.click();
        waitForElement(CreatePost,30);
        Boolean Display = CreatePost.isDisplayed();
        System.out.println("Element displayed is :"+ Display);
    }
    public void PostListAction(){
        driver.navigate().back();
        driver.navigate().back();
        ArrowDown.click();
        MoreActions.click();
        PostsList.click();
        waitForElement(ShowAllButton,30);
        Boolean Display = ShowAllButton.isDisplayed();
        System.out.println("Element displayed is :"+ Display);
    }
    public void CreateFromModulePageAndDeleteOne(){
        ScrollDown();
        DiscussionSideMenu.click();
        CreatePost.click();
        Title.sendKeys("CreateFromModule");
        Next.click();
        ChooseStudent.click();
        Next.click();
        System.out.println(FlashMsg.getText());
        Assert.assertEquals(FlashMsg.getText(),"Your discussion room has been created");
        //Create again
        CreateRoom2.click();
        Title.sendKeys("CreateFromModuleForDeleteTest");
        Next.click();
        ChooseStudent.click();
        Next.click();
        System.out.println(FlashMsg.getText());
        Assert.assertEquals(FlashMsg.getText(),"Your discussion room has been created");
        Delete.click();
        driver.switchTo().alert().accept();
    }
    public void SearchForCreatedDiscussionRoom(){
        SearchField2.sendKeys("CreateFromModule");
        Assert.assertEquals(SearchInModulePage.getText(),"CreateFromModule");
        SearchField2.clear();
        SearchField2.sendKeys("CreateFromModuleForDeleteTest");
        Assert.assertEquals(ExpectedMsg.getText(),"No more discussions to view");
        System.out.println(ExpectedMsg.getText());
        // "لا يوجد المزيد من النقاشات للعرض"
        Home.click();
        ClickOnCourse.click();
        SearchField3.sendKeys("CreateFromModule");
        Assert.assertTrue(ClickOnDiscussionRooms.isDisplayed());
    }
    public void DeleteFunction(){
        SearchField3.clear();
        SearchField3.sendKeys("CreateFromModuleForDeleteTest");
        Assert.assertTrue(ClickOnDiscussionRoomDeleteResults.isDisplayed());

    }




}
