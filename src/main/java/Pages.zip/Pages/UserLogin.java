package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class UserLogin extends PageBase {

    public UserLogin(WebDriver driver) {
        super(driver);
    }
//    @FindBy(xpath = "//*[@id=\"competitionModal\"]/div/div/div[2]/button")
//    public WebElement newPopupCloseBtn;

    @FindBy(id = "UserUsername")
    WebElement UserName;

    @FindBy(id = "UserPassword")
    WebElement Password;

    @FindBy(xpath = "/html/body/div[1]/div[2]/div[1]/div/div/div/div[3]/input\n")
    WebElement LoginBtn;
    public void LoginPage (){
       UserName.sendKeys("demot223");
       Password.sendKeys("12sudo4");
       LoginBtn.click();

    }
}
