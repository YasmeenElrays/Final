package Pages;

import DriverBase.Base;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PageBase extends Base {
    protected WebDriver driverAll;
    public JavascriptExecutor scroll ;

    public PageBase( WebDriver driver){
        PageFactory.initElements(driver,this);

    }
//    public static void scrollTo(WebElement element) {
//        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(false);", element);
//    }}
    public void ScrollDown(){
        scroll.executeScript("window.scrollBy(0,350)");
    }
    public void ScrollUp(){scroll.executeScript("window.scrollBy(0,-350)");}
    public static void waitForElement(WebElement element, int Time) {
            WebDriverWait wait = new WebDriverWait(driver, Time);
            wait.until(ExpectedConditions.visibilityOf(element));
        }
}

