package Tests;

import DriverBase.Base;
import Pages.DiscussionRoom;
import Pages.Roles;
import org.testng.annotations.Test;

public class RolesTCs extends Base {
    Roles RolesObj=new Roles(driver);
    @Test(description = "Check the created discussion Room Displayed for the selected Students ",priority = 11)
    public void CheckStudentRole(){
        RolesObj=new Roles(driver);
        RolesObj.RoleStudent();
    }
    @Test(description = "Check the created Discussion Room Displayed to Guardian",priority = 12)
    public void CheckGuardianRole(){
        RolesObj=new Roles(driver);
        RolesObj.RoleGuardian();
    }
    @Test(description = "Check the created Discussion Room Displayed to managers",priority = 13)
    public void CheckManagerRole() throws InterruptedException {
        RolesObj=new Roles(driver);
        RolesObj.RoleManager();
    }
    @Test(description = "Check The created Discussion Room Displayed to admin",priority = 14)
    public void CheckAdminRole() throws InterruptedException {
        RolesObj = new Roles(driver);
        RolesObj.RoleAdmin();
    }
    @Test(description = " Check Discussion room not displayed when Login as other teacher on same Course and Check the created Discussion Room Displayed For Teacher supervisor ",priority = 15)
    public void CheckTeacherSupervisorAndOtherTeacherRoles() throws InterruptedException {
        RolesObj = new Roles(driver);
        RolesObj.OtherTeacherAndSupervisorRole();
    }
}

