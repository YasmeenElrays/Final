package Tests;

import DriverBase.Base;
import Pages.DiscussionRoom;
import Pages.UserLogin;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class DiscussionRoomTCs extends Base {

    @BeforeClass
    public void setupBrowserBeforeClass(){
        UserLogin Login=new UserLogin(driver);
        Login.LoginPage();
    }
    DiscussionRoom DissRoom;
    @Test(description = "User can Add Discussion Room After Fill Required fields Shared to Student",priority = 1,alwaysRun = true)
    public void ClickOnTheCourse() {
        DissRoom=new DiscussionRoom(driver);
        DissRoom.Course();
        DissRoom.CreateDiscussionRoom();
        DissRoom.SearchWithName();
        DissRoom.SearchInDiscussionRoomModule();

    }
    @Test(description = "User can Create Discussion Room With Hide All New Topics Option ",priority = 2,dependsOnMethods = "ClickOnTheCourse")
    public void CreateDiscussionRooms(){
        DissRoom=new DiscussionRoom(driver);
        //DissRoom.CreateDiscussionRoom();
        DissRoom.CreateDisRoomWithHideAllTopics();
    }
//    @Test(priority = 3,dependsOnMethods = "CreateDiscussionRooms")
//    public void SearchWithDiscussionRoom(){
//        DissRoom=new DiscussionRoom(driver);
//        DissRoom.SearchWithName();
//    }
//    @Test(priority = 4)
//    public void DiscussionRoomPage(){
//        DissRoom=new DiscussionRoom(driver);
//        DissRoom.SearchInDiscussionRoomModule();
//    }
    @Test(description = "Check User can view the Discussion room either when clicking on room title or click on preview Action",priority = 5)
    public void TestViewDiscussionRoom(){
        DissRoom=new DiscussionRoom(driver);
        DissRoom.ViewDiscussionRooms();
    }
    @Test(description = "Check User Can Edit Discussion Room Successfully ",priority = 6)
    public void TestEditDiscussionRoom(){
        DissRoom=new DiscussionRoom(driver);
        DissRoom.EditDiscussionRoom();
    }
    @Test(description = "Check When Click on posts list Action it redirect successfully",priority = 7)
    public void TestPostsList(){
        DissRoom=new DiscussionRoom(driver);
        DissRoom.PostListAction();
    }
    @Test(description = "Check User Can create Discussion Rooms From Module Page and Delete one and Check if it displayed successfully",priority = 8)
    public void TestModulePage(){
        DissRoom=new DiscussionRoom(driver);
        DissRoom.CreateFromModulePageAndDeleteOne();
        DissRoom.SearchForCreatedDiscussionRoom();
        DissRoom.DeleteFunction();
    }
//    @Test(priority =9 )
//    public void SearchCheck(){
//        DissRoom=new DiscussionRoom(driver);
//        DissRoom.SearchForCreatedDiscussionRoom();
//    }
//    @Test(priority = 10)
//    public void CheckDelete(){
//        DissRoom=new DiscussionRoom(driver);
//        DissRoom.DeleteFunction();
//    }
//    @Test(priority = 11)
//    public void CheckStudentRole(){
//        DissRoom=new DiscussionRoom(driver);
//        DissRoom.RoleStudent();
//    }
//    @Test(priority = 12)
//    public void CheckGuardianRole(){
//        DissRoom=new DiscussionRoom(driver);
//        DissRoom.RoleGuardian();
//    }
//    @Test(priority = 13)
//    public void CheckManagerRole(){
//        DissRoom=new DiscussionRoom(driver);
//        DissRoom.RoleManager();
//    }

}
